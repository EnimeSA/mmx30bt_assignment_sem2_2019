-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 19, 2019 at 01:16 PM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `library_db`
--
CREATE DATABASE IF NOT EXISTS `library_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `library_db`;

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE IF NOT EXISTS `admin_tbl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `staffnumber` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `username`, `password`, `staffnumber`) VALUES
(1, 'admin', 'adminpass', 200020);

-- --------------------------------------------------------

--
-- Table structure for table `avail_book_tbl`
--

CREATE TABLE IF NOT EXISTS `avail_book_tbl` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(100) NOT NULL,
  `bookauthor` varchar(100) NOT NULL,
  `bookisbn` int(100) NOT NULL,
  `bookpublisher` varchar(100) NOT NULL,
  `bookyear` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `avail_book_tbl`
--

INSERT INTO `avail_book_tbl` (`id`, `bookname`, `bookauthor`, `bookisbn`, `bookpublisher`, `bookyear`) VALUES
(54, 'herold', 'given', 2102, 'oxford', 1997),
(55, 'HGiven', 'kgyiy', 12564, 'jvsyuyi', 22588);

-- --------------------------------------------------------

--
-- Table structure for table `borwd_book_tbl`
--

CREATE TABLE IF NOT EXISTS `borwd_book_tbl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bookname` varchar(100) NOT NULL,
  `bookauthor` varchar(100) NOT NULL,
  `bookisbn` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `stud_login_tbl`
--

CREATE TABLE IF NOT EXISTS `stud_login_tbl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `studentnumber` int(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `stud_login_tbl`
--

INSERT INTO `stud_login_tbl` (`id`, `username`, `password`, `studentnumber`) VALUES
(1, 'studtest', '1234', 2171),
(2, 'teststud', '1234', 0),
(3, 'given', '2010', 221),
(4, '', '', 0),
(5, '', '', 0),
(6, '', '', 0),
(7, '', '', 0),
(8, 'admin', '1234', 1254),
(9, 'given', '1234', 21777),
(10, 'eminem', 'slimshady', 2145),
(11, 'zwothe', 'zwothe', 2200);

-- --------------------------------------------------------

--
-- Table structure for table `stud_tbl`
--

CREATE TABLE IF NOT EXISTS `stud_tbl` (
  `stud_id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `age` varchar(3) NOT NULL,
  `idnum` int(13) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `cell` varchar(100) NOT NULL,
  PRIMARY KEY (`stud_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `stud_tbl`
--

INSERT INTO `stud_tbl` (`stud_id`, `fname`, `lname`, `age`, `idnum`, `gender`, `email`, `cell`) VALUES
(1, '', '', '', 0, '', '', ''),
(2, 'Given', 'Mutshidza', '22', 9703775, 'Male', 'iamg.herold@gmail.com', '22'),
(3, 'Given', 'Mutshidza', '22', 9703775, 'Male', 'iamg.herold@gmail.com', '22'),
(4, '', '', '', 0, '', '', ''),
(5, '', '', '', 0, '', '', ''),
(6, 'Given', 'Mutshidza', '26', 223445, 'Male', 'sss', '0765598556'),
(7, 'herold', 'enime', '45', 21333, 'Male', 'sss', '0765598556'),
(8, 'herold', 'enime', '45', 21333, 'Male', 'sss', '0765598556'),
(9, 'giveb', 'HEROLD', '22', 2232, 'Male', 'sss', '0765598556'),
(10, 'GIVEN', 'MUTSHIDZA', '25', 2245, 'Male', 'sss', '0765598556'),
(11, 'GIVEN', 'MUTSHIDZA', '22', 2147483647, 'Male', 'sss', '0765598556'),
(12, 'GIVEN', 'HEROLD', '21', 2147483647, 'Male', 'sss', '0765598556'),
(13, 'jhguyuy', 'ihuu', '666', 859889, 'Male', 'sss', '58');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
